//
//
// KIES de naam van het event (hierna Xxx): iets actiefs
//
// bv. Xxx=Switched, 
// bv. Xxx=DocumentLoaded,
// bv. Xxx=OrderAdded
//
//=================================================================

public delegate void XxxEventHandler(object sender, XxxEventArgs e);

//=================================================================

public class XxxEventArgs : EventArgs
{
	// alle data die een belangrijk is bij het event
	private SomeType SomeEventData { get; }
	private SomeOtherType MoreEventData { get; }

	public XxxEventArgs(SomeType someEventData, SomeOtherType moreEventData)
	{
        SomeEventData = someEventData;
        MoreEventData = moreEventData;
	}
}

//=================================================================

public class SomeEventSource
{
	public event XxxEventHandler Xxx;

	public void SomeMethodOrProperty()
	{
		// als er iets gebeurt dat het event zou moeten triggeren, dan
			OnXxx( new XxxEventArgs(someEventData, moreEventData) );
	}

	protected virtual void OnXxx(XxxEventArgs e)
	{
        XxxEventHandler threadSafeOriginal = Xxx;
		threadSafeOriginal?.Invoke(this,e);
	}
}

/*=================================================================
    bijvoorbeeld:
    SomeEventSource  =  Switch
    Xxx  =  Switched
    SomeMethodOrProperty()  =   SwitchMe()
    someEventData  =  state
    moreEventData  =  n.v.t.
*/