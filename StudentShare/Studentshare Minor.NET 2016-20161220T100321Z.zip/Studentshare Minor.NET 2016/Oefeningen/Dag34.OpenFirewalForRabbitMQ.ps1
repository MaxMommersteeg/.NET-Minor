﻿function AddFireWallRules
{
    param(
        [ValidateSet(“RabbitMQ”,”Erlang”,”All”, 1, 2, 3)]
        $answer         
    )

    if($answer -eq "RabbitMQ" -or $answer -eq 1)
    {
        $rabbitmq = Get-NetFirewallRule -DisplayName $(new-netfirewallrule -displayname RabbitMQ -Enabled True -direction inbound -action allow -protocol tcp -RemotePort 5672, 15672, 4369, 25672 -LocalPort 5672, 15672, 4369, 25672 -Profile Any).DisplayName

        Write-Host "The Following Rules Have Been Added:"
        $rabbitmq      
    }
    elseif($answer -eq "Erlang" -or $answer -eq 2)
    {
        $erlang = Get-NetFirewallRule -DisplayName $(new-netfirewallrule -displayname Erlang -Program "%ProgramFiles%\erl8.0\bin\erl.exe" -Enabled True -direction inbound -action allow -protocol tcp -Profile Any).DisplayName
        $erlangRunTime = Get-NetFirewallRule -DisplayName $(new-netfirewallrule -displayname "Erlang Run-Time System" -Program "%ProgramFiles%\erl8.0\erts-8.0\bin\erl.exe" -Enabled True -direction inbound -action allow -protocol tcp -Profile Any).DisplayName
        $erlangPortMapper = Get-NetFirewallRule -DisplayName $(new-netfirewallrule -displayname "Erlang Port Mapper Daemon" -Program "%ProgramFiles%\erl8.0\erts-8.0\bin\epmd.exe" -Enabled True -direction inbound -action allow -protocol tcp -Profile Any).DisplayName

        Write-Host "The Following Rules Have Been Added:"
        $erlang
        $erlangRunTime
        $erlangPortMapper
    }
    elseif($answer -eq "All" -or $answer -eq 3)
    {
        $rabbitmq = Get-NetFirewallRule -DisplayName $(new-netfirewallrule -displayname RabbitMQ -Enabled True -direction inbound -action allow -protocol tcp -RemotePort 5672, 15672, 4369, 25672 -LocalPort 5672, 15672, 4369, 25672 -Profile Any).DisplayName
        $erlang = Get-NetFirewallRule -DisplayName $(new-netfirewallrule -displayname Erlang -Program "%ProgramFiles%\erl8.0\bin\erl.exe" -Enabled True -direction inbound -action allow -protocol tcp -Profile Any).DisplayName
        $erlangRunTime = Get-NetFirewallRule -DisplayName $(new-netfirewallrule -displayname "Erlang Run-Time System" -Program "%ProgramFiles%\erl8.0\erts-8.0\bin\erl.exe" -Enabled True -direction inbound -action allow -protocol tcp -Profile Any).DisplayName
        $erlangPortMapper = Get-NetFirewallRule -DisplayName $(new-netfirewallrule -displayname "Erlang Port Mapper Daemon" -Program "%ProgramFiles%\erl8.0\erts-8.0\bin\epmd.exe" -Enabled True -direction inbound -action allow -protocol tcp -Profile Any).DisplayName   

        Write-Host "The Following Rules Have Been Added:"
        $rabbitmq
        $erlang
        $erlangRunTime
        $erlangPortMapper
    }
}

Write-Host - $("Please select one of the following sets of firewall rules to add:`n" + "1) RabbitMQ`n" + "2) Erlang`n" + "3) All")
$answer = Read-Host -Prompt "Please fill in your answer"

AddFireWallRules -answer $answer

