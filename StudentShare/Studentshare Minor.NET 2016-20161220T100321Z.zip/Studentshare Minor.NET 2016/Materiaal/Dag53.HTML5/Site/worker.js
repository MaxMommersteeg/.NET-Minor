
self.addEventListener('message', (data) => {
    var result = fibonacci(data.data);
    self.postMessage(result);
});

function fibonacci(getal) {
    if (getal === 0 || getal === 1) {
        return 1;
    }

    return fibonacci(getal - 1) + fibonacci(getal - 2);
}