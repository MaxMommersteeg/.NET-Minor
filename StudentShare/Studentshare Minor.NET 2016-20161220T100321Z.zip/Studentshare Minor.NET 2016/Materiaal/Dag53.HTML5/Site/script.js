'use strict';

// "Web Sockets"

// ws:// wss://

var socket;
function openConnection() {
    console.log('Socket openen...');
    socket = new WebSocket('wss://echo.websocket.org');

    socket.addEventListener('open', () => {
        console.log('Socket geopend');
    });
    socket.addEventListener('message', (e) => {
        console.log('Bericht ontvangen!', e.data, e.message);
    });
}
function sendMessage() {
    var message = document.querySelector('#message').value;
    console.log('Bericht versturen!', message);
    socket.send(message);
}






function berekenFibo() {
    var getal = +document.querySelector('#fibo').value;

    var worker = new Worker('worker.js');
    worker.addEventListener('message', (data) => {
        document.querySelector('#fibo-result').innerHTML = data.data;
    })
    worker.postMessage(getal);
}




function getLocation() {

    navigator.geolocation.getCurrentPosition((pos) => {
        document.querySelector('#latitude').innerHTML = pos.coords.latitude;
        document.querySelector('#longitude').innerHTML = pos.coords.longitude;
        document.querySelector('#accuracy').innerHTML = pos.coords.accuracy;
    }, (err) => {
        console.error('Oh noes!', err);
    });
}

if (window.localStorage['counter'] === undefined) {
    window.localStorage['counter'] = 0;
}
window.localStorage['counter']++;
document.querySelector('#local-counter').innerHTML = window.localStorage['counter'];

if (window.sessionStorage['counter'] === undefined) {
    window.sessionStorage['counter'] = 0;
}
window.sessionStorage['counter']++;
document.querySelector('#session-counter').innerHTML = window.sessionStorage['counter'];
