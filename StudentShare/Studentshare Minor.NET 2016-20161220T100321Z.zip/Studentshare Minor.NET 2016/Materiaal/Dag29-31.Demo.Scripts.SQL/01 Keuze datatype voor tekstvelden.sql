---Keuze datatypes voor tekstvelden

-- lengte?  wat is de eis?  
-- unicode nodig?  
-- charters uit default characterset voldoende? unicode nodig?
-- char vs nchar   varchar vs nvarchar    N''
-- vaste lengte of variabele lengte?  char vs varchar  
-- 


SELECT * FROM test ;
GO
--CREATE SCHEMA Demo;
GO
CREATE TABLE Demo.Test 
(
	  kol1   char(4000)
	 ,kol2	char(3000) 
)
;

--Msg 1701, Level 16, State 1, Line 11
--Creating or altering table 'Test' failed because the minimum row size would be 10007, 
--including 7 bytes of internal overhead. 
--This exceeds the maximum allowable table row size of 8060 bytes.

TRUNCATE TABLE Demo.Test3

INSERT INTO demo.test3
SELECT LEFT(kol1,1 ) , Left(kol2, 1)  FROM Demo.Test;

INSERT INTO demo.test  VALUES ('a' , 'b' );


SET STATISTICS IO ON ;
SELECT * FROM Demo.Test 
SELECT COUNT(*) FROM Demo.Test 

CREATE TABLE Demo.Test2 
(
	  Kol1  char(2000)
	 ,kol2	char(3000) 
)
;

SELECT * FROM Demo.Test3
SELECT COUNT(*) FROM Demo.Test2 



CREATE TABLE Demo.Test3 
(
	  Kol1  varchar(4000)
	 ,kol2	varchar(3000) 
)
;

INSERT INTO Demo.Test2 VALUES ('a' + space(2998) + 'c'    , 'v' );



SELECT *
FROM sys.dm_db_index_physical_stats(db_id(),object_id('Demo.test3') , DEFAULT, DEFAULT, 'Detailed') AS t  
