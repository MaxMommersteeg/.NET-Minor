USE AdventureWorks2014 ;

SELECT   OBJECT_NAME(c.object_id ) AS ObjectName
		,c.name
		,t.name 

FROM sys.columns AS c
INNER JOIN sys.types AS t 
ON c.system_type_id = t.system_type_id 
WHERE t.name LIKE '%xml%'


SET STATISTICS IO ON

SELECT BusinessEntityID, Title, FirstName, MiddleName, LastName, Suffix, PhoneNumber, PhoneNumberType
, EmailAddress, EmailPromotion, AddressType, AddressLine1, AddressLine2, City, StateProvinceName
, PostalCode, CountryRegionName, Demographics
FROM Sales.vIndividualCustomer 


SELECT BusinessEntityID, Title, FirstName, MiddleName, LastName, Suffix
, PhoneNumber, PhoneNumberType, EmailAddress, EmailPromotion
, AddressType, AddressLine1, AddressLine2, City, StateProvinceName, PostalCode, CountryRegionName
FROM Sales.vIndividualCustomer 

SELECT  MAX (LEN ( CAST ( Demographics AS VARCHAR(MAX) )) ) AS lengte 
FROM Sales.vIndividualCustomer 


SELECT BusinessEntityID, Title, FirstName, MiddleName, LastName
, Suffix, PhoneNumber, PhoneNumberType, EmailAddress, EmailPromotion
, AddressType, AddressLine1, AddressLine2, City, StateProvinceName
, PostalCode, CountryRegionName, Demographics
FROM Sales.vIndividualCustomer 

SELECT BusinessEntityID, Title, FirstName, MiddleName, LastName, Suffix, PhoneNumber, PhoneNumberType
, EmailAddress, EmailPromotion, AddressType, AddressLine1, AddressLine2, City
, StateProvinceName, PostalCode, CountryRegionName
,CAST ( Demographics AS VARCHAR(6) )
FROM Sales.vIndividualCustomer 