USE Northwind 


SET STATISTICS IO ON 

SELECT OrderID, ProductID, UnitPrice, Quantity, Discount , Vulling 
FROM dbo.[Order Details]
 -- 430 pages 

SELECT OrderID, ProductID, UnitPrice, Quantity, Discount , Vulling 
FROM dbo.[Order Details]
WHERE Unitprice = 9.80 
-- 430 
-- 4

SELECT OrderID, ProductID, UnitPrice, Quantity, Discount , Vulling 
FROM dbo.[Order Details]
WHERE Unitprice + 0.20 = 10.00 

SELECT OrderID, ProductID, UnitPrice, Quantity, Discount , Vulling 
FROM dbo.[Order Details]
WHERE Unitprice  = 10.00 - 0.20


CREATE NONCLUSTERED INDEX ix ON dbo.[Order Details](unitPrice) 




ALTER TABLE dbo.[Order Details]
ADD vulling CHAR(1000)  

UPDATE dbo.[Order Details]
SET vulling = 'a' 

-- 11 pages 