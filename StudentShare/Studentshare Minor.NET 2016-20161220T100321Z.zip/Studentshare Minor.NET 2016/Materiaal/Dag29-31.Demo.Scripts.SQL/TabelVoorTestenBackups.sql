USE oefening ;

CREATE TABLE LogVoorBackup
(
	 id INT identity 
	,informatie varchar(100)
);


INSERT INTO LogVoorBackup VALUES ('Voor Full1' );
INSERT INTO LogVoorBackup VALUES ('Voor Log1' );
INSERT INTO LogVoorBackup VALUES ('Voor Full2' )
INSERT INTO LogVoorBackup VALUES ('Voor Log2' )
INSERT INTO LogVoorBackup VALUES ('Voor Crash' )

SELECT * FROM LogVoorBackup 

BACKUP LOG Oefening
WITH NO_TRUNCATE 