CREATE NONCLUSTERED INDEX ix_persoon ON Person.Person
([BusinessEntityID] )
INCLUDE     ([Title]
    ,[FirstName]
    ,[MiddleName]
    ,[LastName]
    ,[Suffix]
       ,[EmailPromotion]
 
    , CAST ( [Demographics] AS VARCHAR(100)) 
	)


ALTER VIEW Person.vPerson
WITH SCHEMABINDING 
AS SELECT [BusinessEntityID] 
		,	[Title]
    ,[FirstName]
    ,[MiddleName]
    ,[LastName]
    ,[Suffix]
       ,[EmailPromotion]
 
    , CAST ( [Demographics] AS VARCHAR(1000))  AS  'Demographics'
FROM Person.Person  

CREATE UNIQUE  CLUSTERED INDEX ix_clustered_vPerson ON  Person.vPerson([BusinessEntityID] )