USE Pubs 

SET STATISTICS IO ON ;

SELECT title 
		, pubdate 
FROM dbo.titles 
WHERE YEAR(pubdate) = 1991 
;

SELECT title 
		, pubdate 
FROM dbo.titles 
WHERE pubdate BETWEEN '19910101 00:00:00.000' AND '19911231  23:59:59.997'
;

SELECT title 
		, pubdate 
FROM dbo.titles 
WHERE pubdate BETWEEN '19910101 00:00:00.000' AND '19911231  23:59:59.999' -- fout door accuracy 
;


BEGIN TRAN

UPDATE TOP (1) dbo.titles 
SET pubdate ='19920101 00:00:00.000'

ROLLBACK TRAN


INSERT INTO dbo.titles 
SELECT * 
FROM dbo.titles 

