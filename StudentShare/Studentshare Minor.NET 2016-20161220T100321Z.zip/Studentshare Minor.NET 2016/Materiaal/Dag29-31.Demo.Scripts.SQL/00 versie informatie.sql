SELECT @@version ;

Microsoft SQL Server 2016 (RTM) - 13.0.1601.5 (X64) 
  Apr 29 2016 23:23:58   Copyright (c) Microsoft Corporation  Express Edition 
(64-bit) on Windows 10 Enterprise 6.3 <X64> (Build 14393: ) (Hypervisor) 


SELECT SUSER_SNAME() ; -- login , serverprincipal

-- Wisselen van database context 
USE pubs;