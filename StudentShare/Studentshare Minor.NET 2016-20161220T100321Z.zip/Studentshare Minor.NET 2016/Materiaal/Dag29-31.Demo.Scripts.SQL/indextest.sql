CREATE TABLE IndexTest
(
	 kol1 int 
	,kol2 int
	,vulling char(500)
);

DECLARE @t int = 1
SEt NOCOUNT ON ;

WHILE @t <= 1000
BEGIN
 INSERT INTO IndexTest VALUES(@t, @t%10 , 'a');
 SET @t += 1;
END;

SET NOCOUNT OFF;


