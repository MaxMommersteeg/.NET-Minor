BACKUP LOG Oefening
TO DISK = 'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLEXPRESS\MSSQL\Backup\test.bak'
WITH NO_TRUNCATE ;

RESTORE HEADERONLY
FROM disk = 'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLEXPRESS\MSSQL\Backup\test.bak'
  

RESTORE DATABASE oefening
FROM disk = 'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLEXPRESS\MSSQL\Backup\test.bak'
WITH FILE =3
, REPLACE
,NORECOVERY 
RESTORE DATABASE oefening
FROM disk = 'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLEXPRESS\MSSQL\Backup\test.bak'
WITH FILE =2
,NORECOVERY 

RESTORE DATABASE oefening
FROM disk = 'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLEXPRESS\MSSQL\Backup\test.bak'
WITH FILE =4
,NORECOVERY 

RESTORE DATABASE oefening
FROM disk = 'C:\Program Files\Microsoft SQL Server\MSSQL13.SQLEXPRESS\MSSQL\Backup\test.bak'
WITH FILE =5
,RECOVERY 



