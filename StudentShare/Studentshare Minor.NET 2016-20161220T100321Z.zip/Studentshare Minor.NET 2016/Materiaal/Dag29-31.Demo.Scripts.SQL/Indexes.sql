SET STATISTICS IO ON

SELECT kol1 , kol2  , VULLING
FROM indexTest 
WHERE kol1 > 500
;

--85

drop index	INDEXTEST.IX2

CREATE CLUSTERED INDEX ix ON indextest(kol1) 
CREATE NONCLUSTERED INDEX ix2 ON indextest(kol1) INCLUDE (kol2) 

SELECT kol2,  AVG(kol1) 
FROM indextest 
GROUP BY kol2




CREATE NONCLUSTERED INDEX  noncl_kol2 ON indextest(kol2)

SELECT kol2, kol1  ,vulling 
FROM indextest 
WHERE kol2 = 4
-- 3 


EXEC sp_helpindex 'Indextest'