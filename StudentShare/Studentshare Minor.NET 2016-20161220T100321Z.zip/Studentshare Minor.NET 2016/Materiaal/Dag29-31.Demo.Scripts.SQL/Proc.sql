CREATE TYPE tt_ProductQuantity
AS TABLE (ProductNr int , Quantity SMALLINT ) 

GO
CREATE PROC csp_newOrder_i
 @ClientNr char(6) 
,@OrderNr char(10) OUTPUT
,@productQuantity tt_ProductQuantity READONLY
AS 
BEGIN 
	INSERT INTO [Order] (ClientNr) 
	VALUES (@ClientNr)  ;

	-- OrderNr is identity met voorloopnullen
	DECLARE @id VARCHAR(10) = CAST ( SCOPE_IDENTITY() AS VARCHAR(10)) ;
	SET @OrderNr = REPLICATE('0', 10- LEN(@id) )  + @id ;
	-- OrderDate is DEFAULT in tabel SYSDATETIME() 
	
	INSERT INTO OrderDetails
	SELECT @OrderNr , ProductNr, Quantity 
	FROM  @productQuantity;
END 

