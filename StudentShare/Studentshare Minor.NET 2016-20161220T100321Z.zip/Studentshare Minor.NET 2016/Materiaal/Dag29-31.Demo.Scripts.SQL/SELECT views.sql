SET STATISTICS IO ON 

SELECT  *
FROM Sales.vIndividualCustomer 

SELECT  *
FROM Sales.myvIndividualCustomer 

SELECT *
FROM sys.dm_exec_procedure_stats ;


