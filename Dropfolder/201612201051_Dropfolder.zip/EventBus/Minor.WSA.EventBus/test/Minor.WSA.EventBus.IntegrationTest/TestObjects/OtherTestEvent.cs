﻿using Minor.WSA.Common.Events;

namespace Minor.WSA.EventBus.IntegrationTest
{
    internal class OtherTestEvent : DomainEvent
    {
        public OtherTestEvent(string routingKey = "Test.Event")
        {
            RoutingKey = routingKey;
        }
    }
}