﻿using System;

namespace Minor.WSA.Common.Events
{
    public abstract class DomainEvent
    {
        public DateTime TimeStamp { get; } = DateTime.Now;
        public string RoutingKey { get; protected set; } = "";
        public Guid CorrelationID { get; } = Guid.NewGuid();

    }
}
