﻿using Minor.WSA.Common.Events;
using System;

namespace Minor.WSA.Common.Interfaces
{
    public interface IEventPublisher : IDisposable
    {
        void Publish(DomainEvent domainEvent);
    }
}
