﻿using System;
using System.Reflection;

namespace Minor.WSA.EventBus.Domain
{
    public class MethodObject
    {
        public Type type { get; set; }
        public MethodInfo methodInfo { get; set; }
    }
}