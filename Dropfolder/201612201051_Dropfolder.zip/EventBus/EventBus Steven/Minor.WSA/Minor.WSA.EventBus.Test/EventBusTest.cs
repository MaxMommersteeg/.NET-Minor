﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Minor.WSA.EventBus.Config;
using Minor.WSA.EventBus.Publisher;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Minor.WSA.EventBus.Test
{
    [TestClass]
    public class EventBusTest
    {

        private EventBusConfig _config;

        [Microsoft.VisualStudio.TestTools.UnitTesting.TestInitialize]
        public void Before()
        {
            _config = new EventBusConfig();
        }

        [TestMethod]
        public void TestSendReceive()
        {
            var dummyEvent = new DummyEvent() {
                GUID = Guid.NewGuid().ToString(),
                RoutingKey = "hello",
                TimeStamp = DateTime.Now,
                Message = "Hoi Misha"
            };
            using (var dispatcherMock = new EventDispatcherMock(_config))
            using (var publisher = new EventPublisher(_config))
            {
                publisher.Publish(dummyEvent);

                Thread.Sleep(1000);

                Assert.AreEqual(1, dispatcherMock.CallCount);
                Assert.AreEqual("Hoi Misha", dispatcherMock.CalledEvent.Message);
            }
        }
    }
}
