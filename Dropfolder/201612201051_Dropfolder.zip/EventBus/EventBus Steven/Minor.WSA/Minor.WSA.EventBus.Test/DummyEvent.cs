﻿using Minor.WSA.Commons;

namespace Minor.WSA.EventBus.Test
{
    public class DummyEvent : DomainEvent
    {
        public string Message { get; set; }
    }
}