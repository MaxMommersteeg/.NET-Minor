﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Minor.WSA.EventBus.Config;
using Minor.WSA.EventBus.Dispatcher;

namespace Minor.WSA.EventBus.Test
{
    [RoutingKey("#")]
    public class EventDispatcherMock : EventDispatcher
    {

        public DummyEvent CalledEvent { get; private set; }
        public int CallCount { get; private set; }

        public EventDispatcherMock(EventBusConfig config) : base(config)
        {
        }

        public void OnDummyEvent(DummyEvent dummyEvent)
        {
            CalledEvent = dummyEvent;
            CallCount++;
        }
    }
}
