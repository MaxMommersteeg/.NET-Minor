﻿using Minor.WSA.Commons;
using Minor.WSA.EventBus.Config;
using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minor.WSA.EventBus.Publisher
{
    public class EventPublisher : IEventPublisher, IDisposable
    {
        private EventBusConfig _config;
        private IConnection _connection;
        private IModel _channel;

        public EventPublisher(EventBusConfig config)
        {
            _config = config;
            var factory = new ConnectionFactory() { HostName = _config.Host, Port = _config.Port, UserName = _config.Username, Password = _config.Password };
            _connection = factory.CreateConnection();
            _channel = _connection.CreateModel();

            _channel.ExchangeDeclare(exchange: _config.ExchangeName, type: ExchangeType.Topic);
        }

        public void Publish(DomainEvent domainEvent)
        {
            var json = JsonConvert.SerializeObject(domainEvent);
            Publish(domainEvent.RoutingKey, domainEvent.GetType().FullName, json);
        }

        public void Publish(string routingKey, string type, string body)
        {
            var props = _channel.CreateBasicProperties();
            props.Type = type;
            
            var bytes = Encoding.UTF8.GetBytes(body);
            _channel.BasicPublish(
                        exchange: _config.ExchangeName,
                        routingKey: routingKey,
                        basicProperties: props,
                        body: bytes);
        }

        public void Dispose()
        {
            _connection?.Dispose();
            _channel?.Dispose();
        }
    }
}
