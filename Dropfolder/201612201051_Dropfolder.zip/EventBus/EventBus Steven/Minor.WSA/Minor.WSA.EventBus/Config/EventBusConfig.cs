﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.WSA.EventBus.Config
{
    public class EventBusConfig
    {

        public string Host { get; set; } = "localhost";
        public int Port { get; set; } = -1;
        public string Username { get; set; } = "guest";
        public string Password { get; set; } = "guest";
        public string QueueName { get; set; } = "my-queue";
        public string ExchangeName { get; set; } = "my-bus";

    }
}
