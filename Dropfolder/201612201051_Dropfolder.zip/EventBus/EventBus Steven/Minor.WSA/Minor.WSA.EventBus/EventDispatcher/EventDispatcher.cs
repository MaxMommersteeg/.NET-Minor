﻿using Minor.WSA.EventBus.Config;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Reflection;
using RabbitMQ.Client.Events;
using System.Text;
using Newtonsoft.Json;

namespace Minor.WSA.EventBus.Dispatcher
{
    public abstract class EventDispatcher : IDisposable
    {
        private IModel _channel;
        private EventBusConfig _config;
        private IConnection _connection;
        private string RoutingKey { get; }
        private Dictionary<string, MethodInfo> _handlers = new Dictionary<string, MethodInfo>();

        public EventDispatcher(EventBusConfig config)
        {
            // Find routing key
            RoutingKey = GetRoutingKey();
            if (RoutingKey == null)
            {
                throw new ArgumentException("Missing RoutingKey attribute");
            }

           // Find handlers
           _handlers = FindHandlers();

            // Start message bus
            _config = config;
            var factory = new ConnectionFactory() { HostName = _config.Host, Port = _config.Port, UserName = _config.Username, Password = _config.Password };
            _connection = factory.CreateConnection();
            _channel = _connection.CreateModel();

            _channel.ExchangeDeclare(exchange: _config.ExchangeName, type: ExchangeType.Topic);

            _channel.QueueDeclare(queue: _config.QueueName);

            _channel.QueueBind(
                queue: _config.QueueName,
                exchange: _config.ExchangeName,
                routingKey: RoutingKey);


            var consumer = new EventingBasicConsumer(_channel);
            consumer.Received += EventReceived;
            _channel.BasicConsume(queue: _config.QueueName,
                                     noAck: true,
                                     consumer: consumer);
        }

        protected virtual void EventReceived(object sender, BasicDeliverEventArgs e)
        {
            var body = Encoding.UTF8.GetString(e.Body);
            var typeString = e.BasicProperties.Type;
            if (_handlers.ContainsKey(typeString))
            {
                var methodInfo = _handlers[typeString];
                Type type = methodInfo.GetParameters()[0].ParameterType;
                var obj = JsonConvert.DeserializeObject(body, type);
                methodInfo.Invoke(this, new object[] { obj });
            }
        }

        private string GetRoutingKey()
        {
            var routingKeyAttribute = this.GetType().GetTypeInfo().GetCustomAttribute<RoutingKeyAttribute>();
            if (routingKeyAttribute != null)
            {
                return routingKeyAttribute.RoutingKey;
            }
            return null;
        }

        private Dictionary<string, MethodInfo> FindHandlers()
        {
            var handlers = new Dictionary<string, MethodInfo>();
            var methods = GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly);
            foreach(var method in methods)
            {
                var parameters = method.GetParameters();
                if(parameters.Length == 1)
                {
                    var key = parameters[0].ParameterType.FullName;
                    if (!handlers.ContainsKey(key))
                    {
                        handlers.Add(key, method);
                    }
                }
            }
            return handlers;
        }

        public void Dispose()
        {
            _connection?.Dispose();
            _channel?.Dispose();
        }
    }
}
