﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.WSA.Commons
{
    public class DomainEvent
    {

        public DateTime TimeStamp { get; set; }
        public string RoutingKey { get; set; }
        public string GUID { get; set; }

    }
}
