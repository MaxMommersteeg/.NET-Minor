﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.WSA.Commons
{
    public interface IEventPublisher
    {

        void Publish(DomainEvent domainEvent);
        void Publish(string routingKey, string type, string body);

    }
}
