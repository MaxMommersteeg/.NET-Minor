﻿using Microsoft.AspNetCore.Mvc;
using Minor.WSA.AuditLogService.Dispatchers;
using Minor.WSA.AuditLogService.Entities;
using Minor.WSA.AuditLogService.Repositories;
using Minor.WSA.EventBus.Config;
using Minor.WSA.EventBus.Publisher;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.WSA.AuditLogService.Controllers
{
    [Route("/api/v1/logs")]
    public class LogEventController : Controller
    {
        private EventBusConfig _config;
        private LogEventRepository _repo;

        public LogEventController(LogEventRepository repo, EventBusConfig config)
        {
            _repo = repo;
            _config = config;
        }

        [HttpGet]
        public IEnumerable<LogEvent> GetLogs([FromQuery] DateTime minTime)
        {
            IEnumerable<LogEvent> events;
            if (minTime != null)
            {
                events = _repo.FindBy(logEvent => logEvent.Timestamp >= minTime);
            }
            else
            {
                events = _repo.FindAll();
            }

            return events;
        }

        [HttpPost]
        [Route("replay")]
        public IEnumerable<LogEvent> replay([FromQuery] DateTime minTime)
        {
            IEnumerable<LogEvent> events;
            if (minTime != null)
            {
                events = _repo.FindBy(logEvent => logEvent.Timestamp >= minTime);
            }else
            {
                events = _repo.FindAll();
            }

            using(var publisher = new EventPublisher(_config))
            {
                foreach(var logEvent in events)
                {
                    Console.WriteLine(logEvent.RoutingKey + ", " + logEvent.Type + ", " + logEvent.Body);
                    publisher.Publish(logEvent.RoutingKey, logEvent.Type, logEvent.Body);
                }
            }

            return events;
        }

    }
}
