﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Minor.WSA.AuditLogService.Dispatchers;
using Minor.WSA.AuditLogService.Repositories;
using Minor.WSA.AuditLogService.Entities;
using Microsoft.EntityFrameworkCore;
using Minor.WSA.EventBus.Config;
using MySQL.Data.Entity.Extensions;

namespace Minor.WSA.AuditLogService
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);

            if (env.IsEnvironment("Development"))
            {
                // This will push telemetry data through Application Insights pipeline faster, allowing you to view results immediately.
                builder.AddApplicationInsightsSettings(developerMode: true);
            }

            builder.AddEnvironmentVariables();
            Configuration = builder.Build();
            StartDispatcher();
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container
        public void ConfigureServices(IServiceCollection services)
        {

            // Add framework services.
            services.AddApplicationInsightsTelemetry(Configuration);
            services.AddSingleton<EventBusConfig>(new EventBusConfig() {
                QueueName = "audit-queue",
                Host = Configuration.GetConnectionString("RabbitMQ") ?? "localhost"
            });
            services.AddSingleton<LogEventRepository>();
            var sqlConnectionString = Configuration.GetConnectionString("DataAccessMySqlProvider") ?? "server=localhost;port=33306;userid=eventlogs;password=eventlogs;database=eventlogs;";
            services.AddDbContext<LogEventContext>(options =>
                      options.UseMySQL(
                            sqlConnectionString,
                            b => b.MigrationsAssembly("AspNet5MultipleProject"))
                        );
            //        options.UseSqlServer(Configuration["Data:CursusContext:ConnectionString"]));
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            app.UseApplicationInsightsRequestTelemetry();

            app.UseApplicationInsightsExceptionTelemetry();

            app.UseMvc();
        }

        public void StartDispatcher()
        {
            var eventBusConfig = new EventBusConfig()
            {
                QueueName = "audit-queue",
                Host = Configuration.GetConnectionString("RabbitMQ") ?? "localhost"
            };
            var sqlConnectionString = Configuration.GetConnectionString("DataAccessMySqlProvider") ?? "server=localhost;port=33306;userid=eventlogs;password=eventlogs;database=eventlogs;";
            DbContextOptionsBuilder<LogEventContext> builder = new DbContextOptionsBuilder<LogEventContext>();
            builder.UseMySQL(
                            sqlConnectionString,
                            b => b.MigrationsAssembly("AspNet5MultipleProject"));
            var context = new LogEventContext(builder.Options);
            LogEventDispatcher dispatcher = new LogEventDispatcher(eventBusConfig, new LogEventRepository(context));
        }
    }
}
