﻿using Minor.WSA.AuditLogService.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.WSA.AuditLogService.Repositories
{
    public class LogEventRepository : RepositoryBase<LogEvent, string, LogEventContext>
    {
        public LogEventRepository(LogEventContext context) : base(context)
        {
        }

        protected override IQueryable<LogEvent> GetDbSet()
        {
            return _context.LogEvents;
        }

        protected override string GetKeyFrom(LogEvent item)
        {
            return item.Guid;
        }

        public bool HasLogEvent(string guid)
        {
            return this._context.LogEvents.Count(logEvent => logEvent.Guid.Equals(guid)) > 0;
        }
    }
}
