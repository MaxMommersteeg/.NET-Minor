﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.WSA.AuditLogService.Entities
{
    public class LogEventContext : DbContext
    {

        public LogEventContext()
        {
            Database.EnsureCreated();
        }

        public LogEventContext(DbContextOptions options) : base(options)
        {
            Database.EnsureCreated();
        }

        public virtual DbSet<LogEvent> LogEvents { get; set; }

    }
}
