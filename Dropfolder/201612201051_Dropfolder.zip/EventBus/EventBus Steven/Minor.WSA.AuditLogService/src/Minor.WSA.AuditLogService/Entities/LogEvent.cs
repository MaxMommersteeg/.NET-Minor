﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.WSA.AuditLogService.Entities
{
    public class LogEvent
    {

        [Key]
        public string Guid { get; set; }
        [MaxLength(50)]
        public string Type { get; set; }
        [MaxLength(50)]
        public string RoutingKey { get; set; }

        public string Body { get; set; }

        public DateTime Timestamp { get; set; }

    }
}
