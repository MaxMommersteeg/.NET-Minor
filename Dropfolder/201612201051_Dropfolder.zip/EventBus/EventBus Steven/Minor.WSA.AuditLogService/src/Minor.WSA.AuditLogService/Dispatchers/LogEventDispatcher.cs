﻿using Minor.WSA.Commons;
using Minor.WSA.EventBus.Dispatcher;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Minor.WSA.EventBus.Config;
using RabbitMQ.Client.Events;
using System.Text;
using Minor.WSA.AuditLogService.Entities;
using Minor.WSA.AuditLogService.Repositories;
using Minor.WSA.EventBus.Publisher;
using Newtonsoft.Json;

namespace Minor.WSA.AuditLogService.Dispatchers
{
    [RoutingKey("#")]
    public class LogEventDispatcher : EventDispatcher
    {
        private LogEventRepository _logEventRepository;

        public LogEventDispatcher(EventBusConfig config, LogEventRepository logEventRepository) : base(config)
        {
            _logEventRepository = logEventRepository;
        }

        protected override void EventReceived(object sender, BasicDeliverEventArgs e)
        {
            var body = Encoding.UTF8.GetString(e.Body);
            DomainEvent domainEvent = JsonConvert.DeserializeObject<DomainEvent>(body);
            var typeString = e.BasicProperties.Type;
            var logEvent = new LogEvent()
            {
                Guid = domainEvent.GUID,
                Type = typeString,
                RoutingKey = e.RoutingKey,
                Body = body,
                Timestamp = domainEvent.TimeStamp
            };

            Console.WriteLine($"has guid: {domainEvent.GUID} result: {_logEventRepository.HasLogEvent(domainEvent.GUID)}");
            if (!_logEventRepository.HasLogEvent(domainEvent.GUID))
            {
                _logEventRepository.Insert(logEvent);
            }
        }



    }
}
