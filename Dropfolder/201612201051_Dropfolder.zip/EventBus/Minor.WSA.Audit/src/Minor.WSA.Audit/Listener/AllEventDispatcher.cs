﻿using Minor.WSA.Audit.Domain;
using Minor.WSA.Audit.Domain.Contracts;
using Minor.WSA.EventBus.Dispatchers;
using Minor.WSA.EventBus.Domain;
using RabbitMQ.Client.Events;
using System;
using System.Text;

namespace Minor.WSA.Audit.Listener
{
    public class AllEventDispatcher : EventDispatcher
    {
        private IRepository _repo;
        public AllEventDispatcher(IRepository repo, BusOptions options = null) : base(options)
        {
            _repo = repo;
        }

        protected override void OnReceivedEvent(object sender, BasicDeliverEventArgs e)
        {
            var typeEvent = e.BasicProperties.Type;
            var message = Encoding.UTF8.GetString(e.Body);

            _repo.Insert(new SerializedEvent { RoutingKey = e.RoutingKey, EventType = typeEvent, Body = message, TimeReceived = DateTime.Now });
        }        
    }
}
