﻿using Minor.WSA.Common.Events;
using System;

namespace Minor.WSA.Audit.Domain
{
    public class SendAllEventCommand : DomainEvent
    {
        public DateTime? StartTime;
        public DateTime? EndTime;
        public string routingKeyAddress;
    }

}