﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Minor.WSA.Audit.Domain
{
    public class SerializedEvent
    {
        public int ID { get; set; }
        public string RoutingKey { get; set; }
        public string EventType { get; set; }
        public string Body { get; set; }
        public DateTime TimeReceived { get; set; }

        public SerializedEvent(string routingKey, string eventType, string body)
        {
            RoutingKey = routingKey;
            EventType = eventType;
            Body = body;
            TimeReceived = DateTime.Now;
        }

        // Needed for entity framework. 
        // Use constructor above for yourself
        public SerializedEvent()
        {
            TimeReceived = DateTime.Now;
        }
    }
}
