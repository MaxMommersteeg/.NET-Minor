﻿using Microsoft.EntityFrameworkCore;
using Minor.WSA.Audit.Domain;

namespace Minor.WSA.Audit.Infrastructure.Context
{
    public class AuditLogDbContext : DbContext
    {
        public DbSet<SerializedEvent> SerializedEvents { get; set; }

        public AuditLogDbContext(DbContextOptions options) : base(options)
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=AuditLog;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SerializedEvent>()
                .HasKey(serializedEvent => serializedEvent.ID);

            modelBuilder.Entity<SerializedEvent>()
                .Property(serializedEvent => serializedEvent.EventType)
                .HasMaxLength(255)
                .IsRequired();

            modelBuilder.Entity<SerializedEvent>()
                .Property(serializedEvent => serializedEvent.RoutingKey)
                .HasMaxLength(255)
                .IsRequired();

            modelBuilder.Entity<SerializedEvent>()
                .Property(serializedEvent => serializedEvent.Body)
                .HasMaxLength(3999)
                .IsRequired();
        }
    }
}
