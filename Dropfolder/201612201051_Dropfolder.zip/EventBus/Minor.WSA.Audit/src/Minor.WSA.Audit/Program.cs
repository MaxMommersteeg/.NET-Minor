﻿using Microsoft.EntityFrameworkCore;
using Minor.WSA.Audit.Infrastructure.Context;
using Minor.WSA.Audit.Domain.Contracts;
using Minor.WSA.Audit.Infrastructure.Repositories;
using Minor.WSA.Audit.Listener;
using Minor.WSA.EventBus.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Minor.WSA.Audit.Publisher;

namespace Minor.WSA.Audit
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string connectionString = @"Server=.\SQLEXPRESS;Database=AuditLog;Trusted_Connection=True;";

            DbContextOptions options = new DbContextOptionsBuilder().UseSqlServer(connectionString).Options;
            AuditLogDbContext context = new AuditLogDbContext(options);
            BusOptions busOptions = new BusOptions();

            using (IRepository repo = new AuditLogRepository(context))
            using (var all = new AllEventDispatcher(repo, busOptions))
            using (var publisher = new AuditPublisher(busOptions))
            using (var dispatcher = new AuditDispatcher(repo, publisher))
            {

                


            }
        }
    }
}
